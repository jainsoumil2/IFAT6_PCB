import numpy as np
from scipy import signal
import matplotlib.pyplot as plt


class Result:
    def __init__(self, fsig, fs, bw, z0=50):
        self.fsig = fsig
        self.fs = fs
        self.bw = bw
        self.z0 = z0 #?
        self.psd_data_ssb = object
        self.psd_noise_ssb = object
        self.psd_sig_ssb = object
        self.power_sig = object
        self.power_noise_tot = object
        self.power_noise_inband = object
        self.sndr_tot = object
        self.sndr_inband = object
        self.sfdr = object


def spectral_analysis(data, nperseg, fsig, fs, f_low, f_high):
    """
    This function computes SSB(signle sideband) PSD, SNDR and SFDR of measured data. The data is
    composed of a single tone sinusoid + noise and distortion.
    :param data: measured data
    :param nperseg: size of fft. Should be power of 2
    :param fsig: signal frequency
    :param fs: sampling frequency
    :param bw: bandwidth of analysis
    """
    bw = f_high-f_low
    result = Result(fsig, fs, bw)
    result.data_raw=data
    data = data-np.mean(data) # remove the dc component    
    window = np.hanning(nperseg) # nperseg: Number of points in the output window
    f_normalized = fsig / fs
    asd_data = np.zeros(nperseg) # create a zero array
    psd_data = np.zeros(nperseg) # create a zero array
    psd_sig = np.zeros(nperseg) # create a zero array
    psd_noise = np.zeros(nperseg) # create a zero array
    psd_noise_noharm = np.zeros(nperseg) # create a zero array
    u = np.mean(window ** 2)
    num_of_segments = int(len(data) / nperseg) # the number of segments 

    for i in range(num_of_segments):
        data_segment = data[i * num_of_segments:i * num_of_segments + nperseg]
        windowed_sig, windowed_noise = remove_sinusoid(data_segment, window, f_normalized)
        
        windowed_harm_1st, windowed_noise_1 = remove_sinusoid(data_segment, window, 2*f_normalized)
        windowed_noise_noharm=windowed_noise-windowed_harm_1st
        """
        windowed_noise_noharm = data_segment             
        for k in range(num_of_harmonics):
            window1=np.ones(nperseg)
            f_nor_har=(k+1)*f_normalized
            windowed_harm, windowed_noise_noharm=remove_sinusoid(windowed_noise_noharm, window1, f_nor_har)
        """

        fft_data = np.fft.fft(data_segment * window) # apply discrete fourier transform
        fft_sig = np.fft.fft(windowed_sig)
        fft_noise = np.fft.fft(windowed_noise)
        
        fft_data_nowindow=np.fft.fft(data_segment)
        fft_noise_noharm=np.fft.fft(windowed_noise_noharm)

        psd_data += np.abs(fft_data) ** 2 / (u * nperseg)# +=: accumulate num_of_segments
        psd_sig += np.abs(fft_sig.transpose()) ** 2 / (u * nperseg)
        psd_noise += np.abs(fft_noise) ** 2 / (u * nperseg)
        
        psd_noise_noharm += np.abs(fft_noise_noharm) ** 2 / (u * nperseg)
        asd_data +=np.abs(fft_data_nowindow)/nperseg # amplitude spectral density
        
    result.psd_data_ssb = psd_data[0:int(nperseg / 2) + 1] * 2 / num_of_segments # *2 because 
    result.psd_noise_ssb = psd_noise[0:int(nperseg / 2) + 1] * 2 / num_of_segments
    result.psd_sig_ssb = psd_sig[0:int(nperseg / 2) + 1] * 2 / num_of_segments
    
    result.asd_data_ssb = asd_data[0:int(nperseg / 2) + 1] * 2 / num_of_segments
    result.psd_noise_noharm_ssb = psd_noise_noharm[0:int(nperseg / 2) + 1] * 2 / num_of_segments

    result.power_sig = sum(result.psd_sig_ssb) / nperseg # 
    result.power_noise_tot = sum(result.psd_noise_ssb) / nperseg
    result.power_noise_inband = sum(result.psd_noise_ssb[int(f_low / (fs / nperseg) ):int(
        f_high / (fs / nperseg))]) / nperseg
    
    result.power_noise_noharm_inband = sum(result.psd_noise_noharm_ssb[int(f_low / (fs / nperseg) ):int(
        f_high / (fs / nperseg))]) / nperseg
    # result.power_noise_inband = sum(result.psd_noise_ssb[int(fsig / (fs / nperseg) - bw / (fs / nperseg) / 2):int(
    #     fsig / (fs / nperseg) + bw / (fs / nperseg) / 2)]) / nperseg
    
    result.noise_inband=np.sqrt(result.power_noise_inband)
    result.noise_noharm_inband=np.sqrt(result.power_noise_noharm_inband)
    
    result.sndr_tot = 10 * np.log10(result.power_sig / result.power_noise_tot)
    result.sndr_inband = 10 * np.log10(result.power_sig / result.power_noise_inband)
    result.sfdr = 10 * np.log10(max(result.psd_sig_ssb[10:2000]) / max(result.psd_noise_ssb[10:2000]))
    result.snr_inband = 10 * np.log10(result.power_sig / result.power_noise_noharm_inband)
    result.data = data
    result.amplitude=max(result.asd_data_ssb[10:2000])
    result.num_of_segments=num_of_segments
    # result.gain= result.amplitude/(result.Vin*10/(10+10000))
    result.gain= result.amplitude/(result.Vin*10/(2*10000))
    result.input_referred_noise= result.noise_noharm_inband/result.gain # in Vrms
    return result


def plot_result(result):
    f = np.linspace(0, result.fs / 2, len(result.psd_sig_ssb))
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1)
    ax1.semilogy(f, result.psd_data_ssb)
    ax2.semilogy(f, result.psd_sig_ssb)
    ax3.semilogy(f, result.psd_noise_ssb)
    plt.show()


def remove_sinusoid(data_segment: np.ndarray, window: np.ndarray, f_normalized):
    """
    This function takes a data sequence assumed to be of the form
    x[n] = A*sin(2*pi*f_normalized*n + initial_phase) + e[n],
    where e[n] is noise, a window sequence of the same length, and
    f_normalized, and extracts the windowed sinusoid and a DC-free
    version of the windowed noise sequences based on the sinusoidal minimum
    error method (see Simulating and Testing Oversampled Analog-to-Digital
    Converters? by Bernhard Boser et al.)
    abs(y1) * 2 = amplitude of the signal
    :param data_segment: raw data array
    :param window: window array that has the same size as data_segment
    :param float f_normalized: normalized frequency of signal being removed
    """
    w = np.exp(1j * 2 * np.pi * f_normalized) # e^()
    n = np.linspace(0, len(data_segment) - 1, len(data_segment))
    w_powern = np.power(w, n)# =w^n
    windowed_data = data_segment * window
    denominator = np.mean(window) ** 2 - np.mean(window * w_powern ** -2) * np.mean(window * w_powern ** 2) # ** is higher priority than *
    y1 = (np.mean(windowed_data * w_powern ** -1) * np.mean(window) - np.mean(windowed_data * w_powern) * np.mean(
        window * w_powern ** -2)) / denominator
    ym1 = (np.mean(windowed_data * w_powern ** +1) * np.mean(window) - np.mean(
        windowed_data * w_powern ** -1) * np.mean(
        window * w_powern ** +2)) / denominator
    windowed_sig = window * (ym1 * w_powern ** -1 + y1 * w_powern)
    windowed_noise_with_dc = windowed_data - windowed_sig
    windowed_noise = windowed_noise_with_dc - window * np.mean(windowed_data) / np.mean(window)
    return windowed_sig.real, windowed_noise.real


def remove_sinusoid_tb():
    num_of_data = 1000000
    f_signal = 0.3
    f_s = 1
    n = np.linspace(0, num_of_data - 1, num_of_data)
    initial_phase = 0.2
    data = 1.7 * np.sin(2 * np.pi * f_signal / f_s * n + initial_phase) + np.random.normal(0, 1, num_of_data)
    window = signal.windows.boxcar(num_of_data)
    windowed_sig, windowed_noise = remove_sinusoid(data, window, f_signal / f_s)

    f1, psd_data = signal.welch(data, f_s, nperseg=1024 * 32)
    f2, psd_sig = signal.welch(windowed_sig.real, f_s, nperseg=1024 * 32)
    f3, psd_noise = signal.welch(windowed_noise.real, f_s, nperseg=1024 * 32)
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1)
    ax1.semilogy(f1, psd_data)
    ax2.semilogy(f2, psd_sig)
    ax3.semilogy(f3, psd_noise)
    plt.show()
    print('done')


def plot_periodogram_tb():
    num_of_data = 100000000
    f_signal = 0.3
    f_s = 1
    n = np.linspace(0, num_of_data - 1, num_of_data)
    initial_phase = 0.2
    data = 1.7 * np.sin(2 * np.pi * f_signal / f_s * n + initial_phase) + np.random.normal(0, 0.001, num_of_data)
    result = spectral_analysis(data, 1024 * 16, f_signal, f_s, 0.01)
    plot_result(result)
    print('done')


if __name__ == '__main__':
    plot_periodogram_tb()
    print('done')
