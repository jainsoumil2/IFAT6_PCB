# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
#import Lab_instruments
import os
path = "G:\My Drive\MRI Chip\MRI_ADC_Test\MRI_ADC_Python";
os.chdir(path)

import ok
import sys
import string
import time
import re
import numpy as np
import spectrum
import matplotlib.pyplot as plt
from scipy.io import savemat


class Object(object):
    pass


class SsRx:
    def __init__(self):
        self.xem = ok.okCFrontPanel()  # create xem7310 object
        self.xem.bitfile = "B:/Xilinx_MRI_ADC/MRI_ADC/MRI_ADC.runs/impl_1/top.bit"  # Location of the bitfile
        self.xem.OpenBySerial()  # find connected xem7310
        error = self.xem.ConfigureFPGA(self.xem.bitfile)  # load bitfile
        print("Inital FPGA Bit flash complete..")
        print(error)
        return 

    def initDevice(self): # set the SYS_RST
        # self.xem.LoadDefaultPLLConfiguration()
        self.xem.SetWireInValue(0x00,1, 0xffffffff)
        self.xem.UpdateWireIns()
        time.sleep(0.00001) # unit: second
        self.xem.SetWireInValue(0x00,0, 0xffffffff)
        self.xem.UpdateWireIns()
        time.sleep(0.0001)
        self.xem.SetWireInValue(0x00,1,0xffffffff)
        self.xem.UpdateWireIns()
        print("Finish SYS_RST")
        return
    
    def WriteEnable(self): # set the Enable
        time.sleep(0.00001)
        self.xem.SetWireInValue(0x0D,1,0xffffffff)
        self.xem.UpdateWireIns()
        print("Finish Enable")
        return
    
    def WriteDisable(self): # set the Enable
        # time.sleep(0.00001)
        self.xem.SetWireInValue(0x0D,0,0xffffffff)
        self.xem.UpdateWireIns()
        print("Finish Disable")
        return
    
    def ChoppingEnable(self): # set the Enable
        # time.sleep(0.00001)
        self.xem.SetWireInValue(0x1A,1,0xffffffff)
        self.xem.UpdateWireIns()
        print("Chopping Enable")
        return
    
    def ChoppingDisable(self): # set the Enable
        # time.sleep(0.00001)
        self.xem.SetWireInValue(0x1A,0,0xffffffff)
        self.xem.UpdateWireIns()
        print("Chopping Disable")
        return
    
    def RSTPEnable(self): # set the Enable
        # time.sleep(0.00001)
        self.xem.SetWireInValue(0x1B,1,0xffffffff)
        self.xem.UpdateWireIns()
        print("RSTP Enable")
        return
    
    def RSTPDisable(self): # set the Enable
        # time.sleep(0.00001)
        self.xem.SetWireInValue(0x1B,0,0xffffffff)
        self.xem.UpdateWireIns()
        print("RSTP Disable")
        return

    def AD5676_set(self, fullscale,channel, voltage):
        AD5676 = Object()
        AD5676.FS = 2.5
        AD5676.NumBits = 16
        AD5676.dataAddr = 0x01
        AD5676.triggerAddr = 0x40
        AD5676.triggerOffset = 0
        maxvoltage = {
            0: fullscale,  # VPD
            1: fullscale,  # VPC
            2: fullscale,  # VND
            3: fullscale,  # VNC
            4: fullscale,  # VNB
            5: fullscale,  # Vref
            6: fullscale,  # 
            7: fullscale   # 
        }
        channel_code = bin(channel)[2:].zfill(4) # convert the channel number to binary of width 4
        LSB = AD5676.FS / 2 ** AD5676.NumBits
        voltage_code = bin(int(min(voltage, maxvoltage[channel]) / LSB))[2:].zfill(AD5676.NumBits)
        command_code = '0011' # Write to and update DAC channel n
        command = command_code + channel_code + voltage_code
        self.xem.SetWireInValue(AD5676.dataAddr, int(command, 2)) # int(command,2): convert binary command to decimal
        self.xem.UpdateWireIns()
        self.xem.ActivateTriggerIn(AD5676.triggerAddr, AD5676.triggerOffset)
        # print("DAC1 is configured")
        return


    def AD5676_init(self):
        self.AD5676_set(0, 0, 0)
        self.AD5676_set(0, 1, 0)
        self.AD5676_set(0, 2, 0)
        self.AD5676_set(0, 3, 0)
        self.AD5676_set(0, 4, 0)
        self.AD5676_set(0, 5, 0)
        self.AD5676_set(0, 6, 0)
        self.AD5676_set(0, 7, 0)
        
        return
    
    def EN1_high(self): # set the Enable
        self.xem.SetWireInValue(0x02,1,0xffffffff)
        self.xem.UpdateWireIns()
        return    
    def EN1_low(self): # set the Enable
        self.xem.SetWireInValue(0x02,0,0xffffffff)
        self.xem.UpdateWireIns()
        return
    def EN2_high(self): # set the Enable
        self.xem.SetWireInValue(0x03,1,0xffffffff)
        self.xem.UpdateWireIns()
        return    
    def EN2_low(self): # set the Enable
        self.xem.SetWireInValue(0x03,0,0xffffffff)
        self.xem.UpdateWireIns()
        return
    def EN3_high(self): # set the Enable
        self.xem.SetWireInValue(0x04,1,0xffffffff)
        self.xem.UpdateWireIns()
        return    
    def EN3_low(self): # set the Enable
        self.xem.SetWireInValue(0x04,0,0xffffffff)
        self.xem.UpdateWireIns()
        return
  
    def WriteAddress(self,address_mode,channel_address,channel_freqdiv):
        self.xem.SetWireInValue(0x05, address_mode)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x06, channel_address)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x07, channel_freqdiv)
        self.xem.UpdateWireIns()
        print("address is configured")
        return
    
    
    def WritePhaseDelay(self,delay_Phi1):
        self.xem.SetWireInValue(0x09, delay_Phi1)
        self.xem.UpdateWireIns()
        # self.xem.SetWireInValue(0x13, delay_Phi2)
        # self.xem.UpdateWireIns()
        # self.xem.SetWireInValue(0x14, delay_Phi3)
        # self.xem.UpdateWireIns()
        # self.xem.SetWireInValue(0x0E, delay_rst)
        # self.xem.UpdateWireIns()
        # self.xem.SetWireInValue(0x0F, delay_rstp)
        # self.xem.UpdateWireIns()
        print("Phase_delay is configured")
        return
          
    def WritePhaselow(self,Phi1_low,Phi2_low,Phi3_low,rst_low,rstp_low):
        self.xem.SetWireInValue(0x10, Phi1_low)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x11, Phi2_low)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x12, Phi3_low)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x15, rst_low)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x16, rstp_low)
        self.xem.UpdateWireIns()
        print("Phase_low is configured")
        return
    
    def WritePhasehigh(self,Phi1_high,Phi2_high,Phi3_high,rst_high,rstp_high):
        self.xem.SetWireInValue(0x17, Phi1_high)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x18, Phi2_high)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x19, Phi3_high)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x1C, rst_high)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x1D, rstp_high)
        self.xem.UpdateWireIns()
        print("Phase_high is configured")
        return
    
    def WriteOthers(self,Irefclk_freqdiv,VDDclk_freqdiv,ENF_freqdiv,phase_mode,VG,Probe):
        self.xem.SetWireInValue(0x0A, Irefclk_freqdiv)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x0B, VDDclk_freqdiv)
        self.xem.UpdateWireIns()
        self.xem.SetWireInValue(0x0C, ENF_freqdiv)
        self.xem.UpdateWireIns()
        address1F=bin(phase_mode)[2:].zfill(1)+bin(VG)[2:].zfill(1)+bin(Probe)[2:].zfill(1)+'0'*29
        self.xem.SetWireInValue(0x1F, int(address1F,2))
        self.xem.UpdateWireIns()
        print("Others is configured")
        return


    def aquire_data(self,num_of_record,fs):
        buffer = {}
        for i in range(num_of_record):
            buffer[i] = bytearray(65536) # 2^16

        print("start retrieving data from ADC")
        # func_gen.preset_square_wave(1,40e6,1.8,1.2)
#         func_gen.set_output_impedance_HiZ(1)
#         func_gen.preset_sine_wave(1, fs, 2.5, 1.25)
#         func_gen.set_output_state(1, 'ON')

        for i in range(num_of_record):
            if (i % 2 == 0):
                tik_en = 0
                while (tik_en == 0):
                    ssrx.xem.UpdateWireOuts()
                    tik_en = ssrx.xem.GetWireOutValue(0x21)
                ssrx.xem.ReadFromBlockPipeOut(0xa0, 16, buffer[i]) # read data from pipeout
            else:
                tok_en = 0
                while (tok_en == 0):
                    ssrx.xem.UpdateWireOuts()
                    tok_en = ssrx.xem.GetWireOutValue(0x22)
                ssrx.xem.ReadFromBlockPipeOut(0xa1, 16, buffer[i])
#        func_gen.set_output_state(1, 'OFF')

        print("start writing serialized output")
        serialized_out = ''
        for i in range(num_of_record): # i=0 to num_of_record-1
            serialized_out = serialized_out + ''.join(format(byte, '08b') for byte in buffer[i]) # convert the byte data in buffer to bit and put them together
        serialized_out_array = np.array(list(serialized_out), dtype=int) # create an array and define its data-type
        serialized_out_array = serialized_out_array.reshape(int(len(serialized_out_array) / 32), 32) # reshape the array into 32 width
        raw_A = np.concatenate((serialized_out_array[:, 14:16], serialized_out_array[:, 0:8]), axis=1)
        raw_B = np.concatenate((serialized_out_array[:, 20:24], serialized_out_array[:, 8:14]), axis=1)
        raw_C = np.concatenate((serialized_out_array[:, 26:], serialized_out_array[:, 16:20]), axis=1)
        output = np.stack([raw_A, raw_B, raw_C], axis=1).reshape(raw_A.shape[0] * 3, 10) # sort the data and reshape to 10 columns

        rows_to_remove = [0] * 3 * num_of_record  #3?
        for i in range(1, num_of_record + 1):
            rows_to_remove[i * 3 - 3: i * 3] = [i * 49152 - 3, i * 49152 - 2, i * 49152 - 1] #49152?
        output = np.delete(output, rows_to_remove, 0)
        
        output_flat= np.flip(output,axis = 1).flatten()

        # num_of_bit = 10
        # output_flat = np.zeros(output.shape[0])
        # for i in range(num_of_bit):
        #     output_flat = output_flat + output[:, i] * 2 ** (9 - i)

        return output_flat
        
        # textfile = open("B:/Data_FIFO/output.txt", "w")
        # for element in serialized_out:
        #     textfile.write(element + "\n")
        # textfile.close()

        print("finished writing")

ssrx = SsRx()     
   
#%% Start FPGA, no chopping, no RSTP

deviceCount = ssrx.xem.GetDeviceCount()
print(deviceCount)
ssrx.xem.bitfile = "B:/Xilinx_MRI_ADC/MRI_ADC/MRI_ADC.runs/impl_1/top.bit"  # Location of the bitfile
ssrx.xem.OpenBySerial("")  # find connected xem7310
error = ssrx.xem.ConfigureFPGA(ssrx.xem.bitfile)  # load bitfile
print("FPGA configuration error code:")
print(error)

ssrx.initDevice()
ssrx.EN1_high()
ssrx.AD5676_init()
ssrx.EN1_low()
ssrx.EN2_high()
ssrx.AD5676_init()
ssrx.EN2_low()
ssrx.EN3_high()
ssrx.AD5676_init()
ssrx.EN3_low()
print("Finish DAC1/2/3 initialization")
# func_gen = Lab_instruments.AFG3000('GPIB0::8::INSTR')
# curr_source = Lab_instruments.KEI2600B('GPIB0::1::INSTR')

'''
curr_source.set_limit(1,1,1e-3)
curr_source.set_limit(2,1,1e-3)
curr_source.set_current(1,CS_BIAS_curr)
curr_source.set_current(2,RFBUF_curr)
curr_source.set_output_state(1,'ON')
curr_source.set_output_state(2,'ON')
curr_source.release_frontPanel()
'''
# ADC channel selection
address_mode=0
channel_address=4
channel_freqdiv=2
ssrx.WriteAddress(address_mode,channel_address,channel_freqdiv)

# DAC_CLK_freqdiv=10
# ssrx.DAC_CLK(DAC_CLK_freqdiv)

# DAC1 Vref_DAC=1V
ssrx.EN1_high()
VPD = 0.183
VPC = 0.273
VND = 0.619
VNC = 0.527
VNB = 0.4
Vref = 0.1

ssrx.AD5676_set(2.5, 0, VPD)  # VPD
ssrx.AD5676_set(2.5, 1, VPC)  # VPC
ssrx.AD5676_set(2.5, 2, VND)  # VND
ssrx.AD5676_set(2.5, 3, VNC)  # VNC
ssrx.AD5676_set(2.5, 4, VNB)  # VNB
ssrx.AD5676_set(2.5, 5, Vref)  # Vref
ssrx.EN1_low()
print("DAC1 is configured")

                  
# DAC2 Vref_DAC=2.5V
ssrx.EN2_high()
VDDIO = 1.8
VDD2 = 2
VDDrst = 0.8
VDDrstp = 0.8
CDW1 = 0.8 # 0.48
CDW2 = 0.8 # 0.45
RSTtap = 0.4
RSTPtap = 0.4
DAC2full=2.5

ssrx.AD5676_set(DAC2full, 0, VDDIO)   # VDDIO
ssrx.AD5676_set(DAC2full, 1, VDD2)    # VDD2
ssrx.AD5676_set(DAC2full, 2, VDDrst)  # VDDrst
ssrx.AD5676_set(DAC2full, 3, VDDrstp) # VDDrstp
ssrx.AD5676_set(DAC2full, 4, CDW1)    # CDW1
ssrx.AD5676_set(DAC2full, 5, CDW2)    # CDW2
ssrx.AD5676_set(DAC2full, 6, RSTtap)  # RSTtap                 
ssrx.AD5676_set(DAC2full, 7, RSTPtap) # RSTtap 
ssrx.EN2_low()
print("DAC2 is configured")
                 
# DAC3 Vref_DAC=1V
ssrx.EN3_high()
Iref=0.4
VCM = 0.4
VCDS = 0.4
INREFA = 0.4
INREFB = 0.4
VDD = 0.8
Backup1 = 0.4
DAC3full=1.0

ssrx.AD5676_set(DAC3full, 0, Iref)  # Iref
ssrx.AD5676_set(DAC3full, 1, VCM)   # VCM
ssrx.AD5676_set(DAC3full, 2, VCDS)  # VCDS
ssrx.AD5676_set(DAC3full, 3, INREFA)  # INREFA
ssrx.AD5676_set(DAC3full, 4, INREFB)  # INREFB
ssrx.AD5676_set(DAC3full, 5, VDD)      # VDD
ssrx.AD5676_set(DAC3full, 6, Backup1)  # Backup1
ssrx.EN3_low()
print("DAC3 is configured")                 

# set ADC frequency        
# ADC_CLK_freqdiv=20 # 20 means get frequency of 5 MHz
# ssrx.ADC_CLK(ADC_CLK_freqdiv)

Irefclk_freqdiv=0
VDDclk_freqdiv=0
ENF_freqdiv=0
phase_mode=0
VG=1
Probe=0
ssrx.WriteOthers(Irefclk_freqdiv,VDDclk_freqdiv,ENF_freqdiv,phase_mode,VG,Probe)

# Phase

ssrx.WriteEnable()
delay_Phi1=50000
# delay_Phi2=50000
# delay_Phi3=30000
# delay_rst =30000
# delay_rstp=30000

# Phi1_high =20000
# Phi2_high =20000000
# Phi3_high =0
# rst_high  =20000
# rstp_high =0

# Phi1_low  =20000000
# Phi2_low  =20000
# Phi3_low  =20000000
# rst_low   =20000000
# rstp_low  =20000000

ssrx.WritePhaseDelay(delay_Phi1)
# ssrx.WritePhaselow(Phi1_low,Phi2_low,Phi3_low,rst_low,rstp_low)
# ssrx.WritePhasehigh(Phi1_high,Phi2_high,Phi3_high,rst_high,rstp_high)

# time.sleep(0.2)
# ssrx.SPI(0,0,7)
# time.sleep(0.2)


num_of_record = 11 # number of FIFOs to be read
fs = 5e6 #sampling frequency
fsig = 100# input signal frequency
f_low = 1 #bandwidth of intrest
f_high = 1000 
output = ssrx.aquire_data(num_of_record,fs)
length = int(len(output))
# length = 1024*1024
result = spectrum.spectral_analysis(output,length,fsig,fs,f_low,f_high)
savemat('B:/Data_ADC/adcdata.mat', result.__dict__)
spectrum.plot_result(result)
print('finish')

#%%
fs = 5e6 #sampling frequency
fsig = 100# input signal frequency
f_low = 1 #bandwidth of intrest
f_high = 1001 
result1 = spectrum.spectral_analysis(output,1024*1024*4,fsig,fs,f_low,f_high)
savemat('B:/Data_ADC/adcdata_2.mat', result1.__dict__)
spectrum.plot_result(result)
print('finish')

#%% FPGA stop
ssrx.WriteDisable()
ssrx.ChoppingDisable()
ssrx.RSTPDisable()

#%% FPGA restart
ssrx.WriteEnable()

#%% Start FPGA, turn on chopping, or/and RSTP

deviceCount = ssrx.xem.GetDeviceCount()
print(deviceCount)
ssrx.xem.bitfile = "B:/Xilinx_MRI_ADC/MRI_ADC/MRI_ADC.runs/impl_1/top.bit"  # Location of the bitfile
ssrx.xem.OpenBySerial("")  # find connected xem7310
error = ssrx.xem.ConfigureFPGA(ssrx.xem.bitfile)  # load bitfile
print("FPGA configuration error code:")
print(error)

ssrx.initDevice()
ssrx.EN1_high()
ssrx.AD5676_init()
ssrx.EN1_low()
ssrx.EN2_high()
ssrx.AD5676_init()
ssrx.EN2_low()
ssrx.EN3_high()
ssrx.AD5676_init()
ssrx.EN3_low()
print("Finish DAC1/2/3 initialization")
# func_gen = Lab_instruments.AFG3000('GPIB0::8::INSTR')
# curr_source = Lab_instruments.KEI2600B('GPIB0::1::INSTR')

'''
curr_source.set_limit(1,1,1e-3)
curr_source.set_limit(2,1,1e-3)
curr_source.set_current(1,CS_BIAS_curr)
curr_source.set_current(2,RFBUF_curr)
curr_source.set_output_state(1,'ON')
curr_source.set_output_state(2,'ON')
curr_source.release_frontPanel()
'''
# ADC channel selection
address_mode=0
channel_address=1
channel_freqdiv=2
ssrx.WriteAddress(address_mode,channel_address,channel_freqdiv)

# DAC_CLK_freqdiv=10
# ssrx.DAC_CLK(DAC_CLK_freqdiv)

# DAC1 Vref_DAC=1V
ssrx.EN1_high()
VPD = 0.183
VPC = 0.273
VND = 0.619
VNC = 0.527
VNB = 0.4
Vref = 0.1

ssrx.AD5676_set(2.5, 0, VPD)  # VPD
ssrx.AD5676_set(2.5, 1, VPC)  # VPC
ssrx.AD5676_set(2.5, 2, VND)  # VND
ssrx.AD5676_set(2.5, 3, VNC)  # VNC
ssrx.AD5676_set(2.5, 4, VNB)  # VNB
ssrx.AD5676_set(2.5, 5, Vref)  # Vref
ssrx.EN1_low()
print("DAC1 is configured")

                  
# DAC2 Vref_DAC=2.5V
ssrx.EN2_high()
VDDIO = 1.8
VDD2 = 2
VDDrst = 0.8
VDDrstp = 0.8
CDW1 = 0.8 # 0.48
CDW2 = 0.8 # 0.45
RSTtap = 0.4
RSTPtap = 0.4
DAC2full=2.5

ssrx.AD5676_set(DAC2full, 0, VDDIO)   # VDDIO
ssrx.AD5676_set(DAC2full, 1, VDD2)    # VDD2
ssrx.AD5676_set(DAC2full, 2, VDDrst)  # VDDrst
ssrx.AD5676_set(DAC2full, 3, VDDrstp) # VDDrstp
ssrx.AD5676_set(DAC2full, 4, CDW1)    # CDW1
ssrx.AD5676_set(DAC2full, 5, CDW2)    # CDW2
ssrx.AD5676_set(DAC2full, 6, RSTtap)  # RSTtap                 
ssrx.AD5676_set(DAC2full, 7, RSTPtap) # RSTtap 
ssrx.EN2_low()
print("DAC2 is configured")
                 
# DAC3 Vref_DAC=1V
ssrx.EN3_high()
Iref=0.4
VCM = 0.4
VCDS = 0.4
INREFA = 0.4
INREFB = 0.4
VDD = 0.8
Backup1 = 1.2
DAC3full=2.5

ssrx.AD5676_set(DAC3full, 0, Iref)  # Iref
ssrx.AD5676_set(DAC3full, 1, VCM)   # VCM
ssrx.AD5676_set(DAC3full, 2, VCDS)  # VCDS
ssrx.AD5676_set(DAC3full, 3, INREFA)  # INREFA
ssrx.AD5676_set(DAC3full, 4, INREFB)  # INREFB
ssrx.AD5676_set(DAC3full, 5, VDD)      # VDD
ssrx.AD5676_set(DAC3full, 6, Backup1)  # Backup1
ssrx.EN3_low()
print("DAC3 is configured")                 

# set ADC frequency        
# ADC_CLK_freqdiv=20 # 20 means get frequency of 5 MHz
# ssrx.ADC_CLK(ADC_CLK_freqdiv)

Irefclk_freqdiv=0
VDDclk_freqdiv=0
ENF_freqdiv=0
phase_mode=0
VG=1
Probe=0
ssrx.WriteOthers(Irefclk_freqdiv,VDDclk_freqdiv,ENF_freqdiv,phase_mode,VG,Probe)

# Phase
ssrx.ChoppingEnable()
ssrx.RSTPEnable()
ssrx.WriteEnable()
delay_Phi1=40000
ssrx.WritePhaseDelay(delay_Phi1)

num_of_record = 11 # number of FIFOs to be read 
fs = 5e6 #sampling frequency
fsig = 100# input signal frequency
f_low = 1 #bandwidth of intrest
f_high = 1000 
output = ssrx.aquire_data(num_of_record,fs)
length = int(len(output))
# length = 5000000
# length = 1024*1024*4
result = spectrum.spectral_analysis(output,length,fsig,fs,f_low,f_high)
savemat('B:/Data_ADC/chip2_ch1_Vddio1_2V_Vin1_5mV_Vrefdac100mV_chopping_RSTP_11FIFO_6.mat', result.__dict__)
spectrum.plot_result(result)
print('finish')

#%%
from scipy.io import loadmat
result_import = loadmat('B:\Data_ADC\Vin1_5mV_Vref250mV_chip2_ch1_chopping_RSTP_11FIFO.mat')
num_of_record = 11 # number of FIFOs to be read 
fs = 5e6 #sampling frequency
fsig = 100# input signal frequency
f_low = 1 #bandwidth of intrest
f_high = 1000 
output=result_import['data'][0]
# length = int(len(output))
length = 5000000
result = spectrum.spectral_analysis(output,length,fsig,fs,f_low,f_high)
savemat('B:/Data_ADC/Vin1_5mV_Vref250mV_chip2_ch1_chopping_RSTP_11FIFO_processed2.mat', result.__dict__)
spectrum.plot_result(result)
print('finish')
