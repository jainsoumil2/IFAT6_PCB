#------------------------------------------------------------------------
# Inititalise
#------------------------------------------------------------------------

import sys
from pathlib import Path
import platform
import time
import pyvisa

script_dir = Path("IFAT6.py").resolve().parent

ok_files_path = {
    'Darwin': script_dir / 'okFiles' / 'Mac',
    'Windows': script_dir / 'okFiles' / 'Win'
}

'''
Specify the location of supporting API files (ok.py, _ok.so, ...). 
'''
sys_path_to_append = ok_files_path.get(platform.system())

'''
Add the location of supporting API files to systems's path.
'''
if sys_path_to_append:
    sys.path.append(str(sys_path_to_append))                        
else:
    print(f'We might need Opal Kelly drivers for {platform.system()}')

from IFAT6_functions_v2 import *
'''
Specify the location of the bitfile.
Load the bitfile onto Opal Kelly if LOAD BIT FILE = True. Load the bit file on power reset.
Skip loading bitfile if LOAD BIT FILE = False (rely on flash).
'''

bit_file_path = script_dir / 'BIT_FILES' / 'top.bit'                
LOAD_BIT_FILE = True                                               
#LOAD_BIT_FILE = False                                             

if LOAD_BIT_FILE:
    FPGA.loadBitFile(str(bit_file_path))

'''
RESET_DEVICE = True
#RESET_DEVICE = False
if RESET_DEVICE:
    FPGA.initDevice() 

 Write '0111b' to reset the ADC state machine (bit 2), DAC state machine (bit 1) 
 and the 50MHz clock IP (bit 0).
'''
write_WireIn(FPGA, 0x00, 0x0000_0007)       
write_WireIn(FPGA, 0x00, 0x0000_0000)
write_WireIn(FPGA, 0x02, 0x0000_0000)       # DAC LDACb
write_WireIn(FPGA, 0x03, 0x0000_001f)       # DAC CLRb

'''
func_gen = Lab_instruments.AFG3000('GPIB0::8::INSTR')
curr_source = Lab_instruments.KEI2600B('GPIB0::1::INSTR')
'''

#%%
#------------------------------------------------------------------------
# Write to DACs
#------------------------------------------------------------------------

DAC_Int_Ref_Enable(FPGA, 1)               # Enable internal reference for DAC1.
write_DAC(FPGA, 1, VREF_2, 2)
write_DAC(FPGA, 1, DVDD, 1.2)
write_DAC(FPGA, 1, VREF_1_8, 1.8)
write_DAC(FPGA, 1, AVDD, 1.8)
write_DAC(FPGA, 1, DVDD_HIGH, 1.8)
write_DAC(FPGA, 1, EVDD, 1.8)

write_DAC(FPGA, 2, V_TAU0, 1.6)
write_DAC(FPGA, 2, V_TAU1, 0.2)
write_DAC(FPGA, 2, V_TAU2, 0.2)
write_DAC(FPGA, 2, V_TAU3, 0.2)
write_DAC(FPGA, 2, GCOMP, 0)
write_DAC(FPGA, 2, GLEAK_PROXIMAL, 0.2)
write_DAC(FPGA, 2, GLEAK_DISTAL, 0.2)
write_DAC(FPGA, 2, ELEAK, 0.0)

write_DAC(FPGA, 3, VBIAS_SF, 0.0)
write_DAC(FPGA, 3, VAMP_HIGH, 0.0)
write_DAC(FPGA, 3, VBIAS_UNITYBUFFER, 0)
write_DAC(FPGA, 3, VAMP_LOW, 0.0)
write_DAC(FPGA, 3, VSPIKE, 1.8)
write_DAC(FPGA, 3, VSS_SYN, 0.0)
write_DAC(FPGA, 3, SYNAPSE_DRIVE_LOW, 0.0)
write_DAC(FPGA, 3, VREFR, 0.1)

write_DAC(FPGA, 4, EREV0, 0.0)
write_DAC(FPGA, 4, EREV1, 0.0)
write_DAC(FPGA, 4, EREV2, 0.0)
write_DAC(FPGA, 4, EREV3, 0.0)
write_DAC(FPGA, 4, VTHRESH, 0.0)
write_DAC(FPGA, 4, VRESET, 0.0)
write_DAC(FPGA, 4, VPDN, 0.6)
write_DAC(FPGA, 4, VBIAS, 1.2)

write_DAC(FPGA, 5, VBP, 0.9)
write_DAC(FPGA, 5, WIDTH_BIAS_HIGH, 0.0)
write_DAC(FPGA, 5, WIDTH_BIAS_LOW, 0.0)
write_DAC(FPGA, 5, VpupReq, 0.8)
write_DAC(FPGA, 5, Vpup_arb, 0.8)
write_DAC(FPGA, 5, VINPUT_CURRENT_BIAS, 1.2)
write_DAC(FPGA, 5, WIDTH_BIAS, 0.0)
write_DAC(FPGA, 5, VDD_1_2, 1.2)

#%% 
#------------------------------------------------------------------------
# Test Clocks
#------------------------------------------------------------------------
write_WireIn(FPGA, 0x0c, 0x06)            # probe DACs and ADC clock. 
write_WireIn(FPGA, 0x0c, 0x00) 

#%% 
#------------------------------------------------------------------------
# Initialise ADC ADS7067
#------------------------------------------------------------------------

'''
Reset the ADC state Machine.
'''
write_WireIn(FPGA, 0x00, 0x0000_0004)
write_WireIn(FPGA, 0x00, 0x0000_0000)

'''
Configure the ADC state machine parameters.
# configure_ADC(FPGA, Low_Time, High_Time, Conversion_Time, Frame_Size, Num_Samples)
'''
configure_ADC(FPGA, 2, 2, 95, 24, 1)

'''
Clear Brown out reset indicator in the SYSTEM_STATUS register (Address = 0x0).
BOR field (bit 0) is set if a brown out condition occurs or the device is power cycled. 

Check CRCERR_FUSE field (bit 2) as well. If the bit is set, it means that the power-up
configuration did not load correctly.
'''
write_ADC(FPGA, 0x080001)         
read_ADC(FPGA, 0x100000)         # 0 for reading from internal register, 1 for reading a channel

'''
Software reset all registers to their default values by setting RST field (bit 0) in
the GENERAL_CFG register at address location 0x01. 

According to the switching characterisics table in the datasheet, the device reset 
takes a maximum of 5ms, after which the RST bit (0) is automatically reset to 0b,
and the Brown Out Reset (BOR) indicator bit is set to 1b.
'''
write_ADC(FPGA, 0x080101)
time.sleep(5e-3)                
read_ADC(FPGA, 0x100000)

'''
Clear Brown out reset indicator. 
'''
write_ADC(FPGA, 0x080001)
read_ADC(FPGA, 0x100000)

'''
Calibrate the ADC offset, and then verify if the calibration has been completed. 
Bit 1 of the 8-bit readout register data, obtained using the 'read_ADC' function call,
should be cleared to 0 once the calibration is complete.
'''
write_ADC(FPGA, 0x080102)
read_ADC(FPGA, 0x100100)

'''
Set APPEND_STATUS[1:0] in 0x02 -- Displays CHID field in the output data.
'''
write_ADC(FPGA, 0x080210)

'''
Disable Manual mode in ADC FSM
'''
write_WireIn(FPGA, 0x09, 0x00000000)

'''
Optionally, to debug communication with the device, FIX_PAT field (bit 7) in DATA_CFG 
register at location 0x02 could be set. The device outputs fixed code 0xA5A5 repetitively
when reading ADC data.
write_ADC(FPGA, 0x080280)
'''

#%%
#------------------------------------------------------------------------ 
# Diagnostics - Bit-walk test mode 
#------------------------------------------------------------------------

'''
 1. Write 0x96 to the DIAGNOSTICS_KEY register at location 0xBF. 
    This action enables write access to diagnostic registers at locations 0xC0, 0xC1 and 0xC2.
 2. Enable diagnostics by setting the BITWALK_EN field (bit 0) in the 
    DIAGNOSTICS_EN register at location 0xC0.
 3. Write to the BIT_SAMPLE_LSB register at location 0xC1.
 4. Write to the BIT_SAMPLE_MSB register at location 0xC2.
 5. Configure the desired channel ID in the MANUAL_CHID field of the CHANNEL_SEL 
    register at location 0x11.
 6. Send an additional 24 serial clock cycles for acqusition (sampling) of the 
    newly selected MUX channel.
 7. Initiate conversion (CSb rising edge), read the conversion result, and save
    the converted output in a 'data_out' variable.
 8. Assuming the output data frame is 24 bits long, discard the first 8 bits with a  
    right-shift operation, and further convert the readout digital code to its 
    analog value by dividing by 65,536 and multiplying the result 
    by the ADC reference voltage.
'''

write_ADC(FPGA, 0x08BF96)
read_ADC(FPGA, 0x10BF00)                # Verify the contents of the register location 0xBF.

write_ADC(FPGA, 0x08C001)               
read_ADC(FPGA, 0x10C000)

write_ADC(FPGA, 0x08C100)
read_ADC(FPGA, 0x10C100)

write_ADC(FPGA, 0x08C280)              
read_ADC(FPGA, 0x10C200)

write_ADC(FPGA, 0x081104)               # Switch to channel 4 (arbitrary).
write_ADC(FPGA, 0x000000)
data_out = read_ADC(FPGA, 0x000000)

data_out = int(data_out, 16)>>8
print((data_out/2**16)*VREF_1_8v)

#%% 
#------------------------------------------------------------------------
# Diagnostics - Fixed voltage test mode, verify 1.8v on AIN6
#------------------------------------------------------------------------

'''
 1. Write 0x96 to the DIAGNOSTICS_KEY register at location 0xBF. 
    This action enables write access to diagnostic registers at 
    locations 0xC0, 0xC1 and 0xC2.
 2. Enable diagnostics by setting the VTEST_EN field (bit 4) in the 
    DIAGNOSTICS_EN register at location 0xC0.
 3. Configure the desired channel ID in the MANUAL_CHID field of the CHANNEL_SEL 
    register at location 0x11.
 4. Send an additional 24 serial clock cycles for acqusition (sampling) of the 
    newly selected MUX channel.
 5. Initiate conversion (CSb rising edge), read the conversion result, and save
    the converted output in a 'data_out' variable.
 6. Assuming the output data frame is 24 bits long, discard the first 8 bits with a  
    right-shift operation, and further convert the readout digital code to its 
    analog value by dividing by 65,536 and multiplying the result 
    by the ADC reference voltage.
'''

write_ADC(FPGA, 0x08BF96)        
read_ADC(FPGA, 0x10BF00)

write_ADC(FPGA, 0x08C010)         
read_ADC(FPGA, 0x10C000)

write_ADC(FPGA, 0x081106)               # Switch to Channel 6. 
write_ADC(FPGA, 0x000000)
data_out = read_ADC(FPGA, 0x000000)

data_out = int(data_out, 16)>>8
print((data_out/2**16)*VREF_1_8v)


#%% 
#------------------------------------------------------------------------
# Disable diagnostics
#------------------------------------------------------------------------

'''
 1. Disable diagnostics by resetting the BITWALK_EN/VTEST_EN field 
    in the DIAGNOSTICS_EN register at location 0xC0.
 2. Reset the DIAGNOSTICS_KEY register at location 0xBF.
'''

write_ADC(FPGA, 0x08C000) 
read_ADC(FPGA, 0x10C000)

write_ADC(FPGA, 0x08BF00) 
read_ADC(FPGA, 0x10BF00)

#%% 
#------------------------------------------------------------------------
# Read using Manual Sequence Mode
#------------------------------------------------------------------------

'''
 1. Configure all channels as analog inputs (AIN) by writing 0x00 to the PIN_CFG
    register at location 0x05.
 2. Calibrate the ADC offset error by setting the CAL field (bit 1) of the GENERAL_CFG
    register at location 0x01.
 3. Select the SEQ_MODE field of the SEQUENCE_CFG register at location 0x10 to 
    Manual Sequence Mode (00b).
 4. Configure the desired channel ID in the MANUAL_CHID field of the CHANNEL_SEL 
    register at location 0x11.
 5. Send an additional 24 serial clock cycles for acqusition (sampling) of the 
    newly selected MUX channel.
 6. Initiate conversion (CSb rising edge), read the conversion result, and save
    the converted output in a 'data_out' variable.
 7. Assuming the output data frame is 24 bits long, discard the first 8 bits with a  
    right-shift operation, and further convert the readout digital code to its 
    analog value by dividing by 65,536 and multiplying the result 
    by the ADC reference voltage.
'''

write_ADC(FPGA, 0x080500)
read_ADC(FPGA, 0x100500)

write_ADC(FPGA, 0x080102)
read_ADC(FPGA, 0x100100)                    # Check if calibration is done.

write_ADC(FPGA, 0x081000)

write_ADC(FPGA, 0x081107)                 
write_ADC(FPGA, 0x000000)                  
data_out = read_ADC(FPGA, 0x000000)

data_out = int(data_out, 16)>>8
print((data_out/2**16)*VREF_1_8v)